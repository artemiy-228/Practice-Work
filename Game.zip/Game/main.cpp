#define WIDTH 900
#define LENGTH 1600
#include <cmath>
#include <graphics.h>

struct House{
   int pos_x;
   int pos_y;
   int size;
};
struct Dancers{
   int pos_x;
   int pos_y;
   IMAGE *image[8];
};
struct Trees{
   int pos_x;
   int pos_y;
   int size;
};
struct Cars{
   int pos_x;
   int pos_y;
   int speed;
   int vector;
   IMAGE *image[12];
};
struct Cat{
   int pos_x;
   int pos_y;
   int speed;
   IMAGE *image[4];
};
struct Clouds{
   int pos_x;
   int pos_y;
   int size;
   int speed;
};
struct Lamp{
   int pos_x;
   int pos_y;
   int len;
};
struct Mushroom{
   int pos_x;
   int pos_y;
   int size;
   int type;
};
struct Sun{
   int pos_x;
   double pos_y;
   IMAGE *image[3];
};
struct Airplane{
   int pos_x;
   int pos_y;
   int speed;
   IMAGE *image[6];
};



void draw_night_scene();
void draw_sun(Sun *sun, int k);
void draw_road();
void draw_background();
void draw_cloud(Clouds *cloud);
void move_cloud(Clouds *cloud);
void draw_car(Cars *car, int k);
void move_car(Cars *car);
void draw_earth();
void draw_dancer(Dancers *dancer, int k);
void draw_house(House *house);
void draw_tree(Trees *tree);
void draw_photo();
void draw_airplane(Airplane *plane, int k);
void draw_lamp(Lamp *lamp, Sun *sun);
void draw_cat(Cat *cat, int k);
void draw_mushroom(Mushroom *mushroom);



int main(){
   int k = 0;
   initwindow(LENGTH, WIDTH, "Game");
   srand(time(0));
   Sun sun = {-150,  100 - 5 * sqrt(sun.pos_x),  {loadBMP("sun/sun1.bmp"), loadBMP("sun/sun2.bmp"), loadBMP("sun/sun3.bmp")}};
   
   Dancers rei = {1100, 250, {loadBMP("Dancer1/dancer1.bmp"), loadBMP("Dancer1/dancer2.bmp"), 
      loadBMP("Dancer1/dancer3.bmp"), loadBMP("Dancer1/dancer4.bmp"), 
      loadBMP("Dancer1/dancer5.bmp"), loadBMP("Dancer1/dancer6.bmp"), 
      loadBMP("Dancer1/dancer7.bmp"), loadBMP("Dancer1/dancer8.bmp")}};
      
   Dancers aska = {1350, 250, {loadBMP("Dancer2/dancer1.bmp"), loadBMP("Dancer2/dancer2.bmp"), 
      loadBMP("Dancer2/dancer3.bmp"), loadBMP("Dancer2/dancer4.bmp"), 
      loadBMP("Dancer2/dancer5.bmp"), loadBMP("Dancer2/dancer6.bmp"), 
      loadBMP("Dancer2/dancer7.bmp"), loadBMP("Dancer2/dancer8.bmp")}};
   
   Cars car = {-400, 800, 15, 1, {loadBMP("car/car.bmp"), loadBMP("car/car1.bmp"), loadBMP("car/car2.bmp"), loadBMP("car/car3.bmp")}};
   
   Trees tree[3] = {{500, 500, 100 + rand() % 50}, {625, 500, 100 + rand() % 50}, {750, 500, 100 + rand() % 50}};

   Airplane plane = {-213, 100, 20, {loadBMP("plane/plane1.bmp"), loadBMP("plane/plane2.bmp"), 
      loadBMP("plane/plane3.bmp"), loadBMP("plane/plane4.bmp"), 
      loadBMP("plane/plane5.bmp"), loadBMP("plane/plane6.bmp")}};
   
   Clouds cloud[5] = {{rand() % LENGTH, rand() % 100 + 100, (rand() % 3  + 2) * 15, (rand() % 3 - 3)}, 
   {rand() % LENGTH, rand() % 100 + 100, (rand() % 3  + 2) * 15, (rand() % 3 - 3)}, 
   {rand() % LENGTH, rand() % 100 + 100, (rand() % 3  + 2) * 15, (rand() % 3 - 3)}, 
   {rand() % LENGTH, rand() % 100 + 100, (rand() % 3  + 2) * 15, (rand() % 3 - 3)},                          
   {rand() % LENGTH, rand() % 100 + 100, (rand() % 3  + 2) * 15, (rand() % 3 - 3)}};
   
   House home = {200, 400, 150};
   
   Lamp lamp[3] = {{400, 500, 200}, {750, 500, 200}, {1000, 500, 200}};
   
   Cat cat = {0, 550, 2, {loadBMP("cat/cat1.bmp"), loadBMP("cat/cat2.bmp"), loadBMP("cat/cat3.bmp"), loadBMP("cat/cat4.bmp")}};
   
   Mushroom mushrooms[5] = {{650, 675, 10, 1}, {670, 700, 10, 2}, {700, 670, 10, 1}, {560, 660, 10, 2}, {790, 680, 10, 1}};
   
   

   while(true){
      draw_background();
      draw_dancer(&rei, k / 2);
      draw_dancer(&aska, k / 2);
      draw_earth();
      draw_road();
      draw_house(&home);
      draw_sun(&sun, k / 4);
      draw_car(&car, k);
      move_car(&car);
      draw_airplane(&plane, k / 6);
      draw_cat(&cat, k / 4);
      for(int i = 0;i < 5;i++){
         draw_cloud(&cloud[i]);
         move_cloud(&cloud[i]);
         draw_mushroom(&mushrooms[i]);
      }
      for(int i = 0;i < 3;i++){
         draw_tree(&tree[i]);
      }
      for(int i = 0;i < 3;i++){
         draw_lamp(&lamp[i], &sun);
      }
      draw_cat(&cat, k / 4);
      k++;
      swapbuffers();
   }
}

void draw_sun(Sun *sun, int k){
   double a = 0.0001;
   int h = LENGTH / 2;
   putimage(sun->pos_x, sun->pos_y, sun->image[k % 3], TRANSPARENT_PUT);
   sun->pos_x += 1;
   sun->pos_y = a * (sun->pos_x - h) * (sun->pos_x - h);
   if(sun->pos_x > LENGTH){
      sun->pos_x = -150;
      sun->pos_y = 100 - 5 * sqrt(sun->pos_x); 
   }
}


void draw_background(){
   setbkcolor(COLOR(175, 238, 238));
   cleardevice();
}

void draw_cloud(Clouds *cloud) {
    setcolor(COLOR(248, 248, 248));
    setfillstyle(SOLID_FILL, WHITE);
    fillellipse(cloud->pos_x, cloud->pos_y, cloud->size, cloud->size / 2);
    fillellipse(cloud->pos_x - cloud->size / 2, cloud->pos_y + cloud->size / 4, cloud->size, cloud->size / 2);
    fillellipse(cloud->pos_x + cloud->size / 2, cloud->pos_y + cloud->size / 4, cloud->size, cloud->size / 2);
    fillellipse(cloud->pos_x - cloud->size, cloud->pos_y, cloud->size, cloud->size / 2);
    fillellipse(cloud->pos_x + cloud->size, cloud->pos_y, cloud->size, cloud->size / 2);
}

void move_cloud(Clouds *cloud){
   cloud->pos_x += cloud->speed;
   if(cloud->pos_x < 0){
      cloud->pos_x = LENGTH;
   }
}

void draw_earth(){
  for (double y = 600; y < WIDTH; y++){
      int c = (1 - y / WIDTH) * 255;
      setcolor(COLOR(255 - c * 3, 255, 255 - c * 3));
      line(0, y, LENGTH - 1, y);
   }
}

void draw_photo(){
   IMAGE *photo;
   photo = loadBMP("photo.bmp");
   putimage(110, 500, photo, COPY_PUT);
}

void draw_road(){
   setcolor(COLOR(73, 77, 78));
   setfillstyle(SOLID_FILL, COLOR(73, 77, 78));
   bar(0, 750, LENGTH, WIDTH);
   setcolor(WHITE);
   setfillstyle(SOLID_FILL, WHITE);
   for(int i = 0;i < 10;i++){
      bar(160 * i, 825, 160 * i + 120 , 840);
   }
}
void draw_dancer(Dancers *dancer, int k) {
   putimage(dancer->pos_x, dancer->pos_y, dancer->image[k % 8], TRANSPARENT_PUT);
}
void draw_car(Cars *car, int k){
   if(car->pos_x <=1000){
      putimage(car->pos_x, car->pos_y, car->image[k % 4], TRANSPARENT_PUT);
   }
   else{
      putimage(car->pos_x, car->pos_y, car->image[k / 5 % 4], TRANSPARENT_PUT);
   }
}

void move_car(Cars *car){
   car->pos_x += car->speed * car->vector;
   if(car->pos_x > 1000){
      car->speed = 3;
      if(car->pos_x > LENGTH){
         car->pos_x = -400;
         car->speed = 15;
   }
   }
}

void draw_house(House *house){
   setcolor(COLOR(245, 245, 220));
   setfillstyle(SOLID_FILL, COLOR(245, 245, 220));
   bar(house->pos_x - house->size,house->pos_y, house->pos_x + house->size, house->pos_y + 2 * house->size);
   
   setcolor(COLOR(196, 30, 58));
   setfillstyle(SOLID_FILL, COLOR(196, 30, 58));
   bar(house->pos_x + 60, house->pos_y + 180, house->pos_x + 120, house->pos_y + 300);
   
   setcolor(COLOR(121, 6, 4));
   setfillstyle(SOLID_FILL, COLOR(121, 6, 4));
   bar(house->pos_x + 70, house->pos_y + 190, house->pos_x + 110, house->pos_y + 235);
   bar(house->pos_x + 70, house->pos_y + 245, house->pos_x + 110, house->pos_y + 290);
   
   setcolor(BLACK);
   setfillstyle(SOLID_FILL, COLOR(212, 175, 55));
   fillellipse(house->pos_x + 115, house->pos_y + 240, 5, 5);
   
   draw_photo();
   
   setcolor(BLACK);
   setfillstyle(SOLID_FILL, BLACK);
   bar(house->pos_x - 90, house->pos_y + 100, house->pos_x + 10, house->pos_y + 102);
   bar(house->pos_x - 90, house->pos_y + 150, house->pos_x + 10, house->pos_y + 152);
   bar(house->pos_x - 90, house->pos_y + 198, house->pos_x + 10, house->pos_y + 200);
   
   bar(house->pos_x - 90, house->pos_y + 100, house->pos_x - 88, house->pos_y + 200);
   bar(house->pos_x - 40, house->pos_y + 100, house->pos_x -38, house->pos_y + 200);
   bar(house->pos_x + 8, house->pos_y + 100, house->pos_x + 10, house->pos_y + 200);
   setcolor(COLOR(89, 25, 31));
   setfillstyle(SOLID_FILL, COLOR(89, 25, 31));
   int roof[6]= {house->pos_x - house->size - 30, house->pos_y + 36, house->pos_x + house->size + 30, house->pos_y + 36, house->pos_x, house->pos_y - house->size + 10};
   fillpoly(3, roof);
   
   setcolor(COLOR(0, 191, 255));
   setfillstyle(SOLID_FILL, COLOR(0, 191, 255));
   fillellipse(house->pos_x, house->pos_y - house->size + 110, 30, 30);
   setcolor(BLACK);
   circle(house->pos_x, house->pos_y - house->size + 110, 30);
   circle(house->pos_x, house->pos_y - house->size + 110, 29);
   circle(house->pos_x, house->pos_y - house->size + 110, 28);
   
}



void draw_tree(Trees* tree) {
   setcolor(COLOR(101, 67, 33));
   setfillstyle(SOLID_FILL, COLOR(101, 67, 3));
   bar(tree->pos_x - 20, tree->pos_y, tree->pos_x + 20, tree->pos_y + 150);
   setcolor(COLOR(1, 50, 32));
   setfillstyle(SOLID_FILL, GREEN);
   fillellipse(tree->pos_x, tree->pos_y - 50, tree->size / 2, tree->size);

}

void draw_airplane(Airplane *plane, int k){
   putimage(plane->pos_x, plane->pos_y, plane->image[k % 6], TRANSPARENT_PUT);
   plane->pos_x += plane->speed;
   if(plane->pos_x > LENGTH){
      plane->pos_x = -213;
   }
}

void draw_lamp(Lamp *lamp, Sun *sun){
   setcolor(BLACK);
   setfillstyle(SOLID_FILL, COLOR(40, 40, 40));
   bar(lamp->pos_x, lamp->pos_y, lamp->pos_x + 20, lamp->pos_y + lamp->len);
   bar(lamp->pos_x, lamp->pos_y, lamp->pos_x + lamp->len / 2, lamp->pos_y + 20);
   bar(lamp->pos_x + lamp->len / 2 - 20, lamp->pos_y, lamp->pos_x + lamp->len / 2, lamp->pos_y + 60);

   if(sun->pos_x > LENGTH / 2){
      setcolor(BLACK);
      setfillstyle(SOLID_FILL, YELLOW);
   }
   else{
      setcolor(BLACK);
      setfillstyle(SOLID_FILL, WHITE);
   }
   fillellipse(lamp->pos_x + lamp->len / 2 - 10, lamp->pos_y + 90, 15, 30);   
}

void draw_cat(Cat *cat, int k){
   if(cat->speed > 0){
      putimage(cat->pos_x,cat->pos_y, cat->image[k % 2], TRANSPARENT_PUT);
   }
   else{
      putimage(cat->pos_x,cat->pos_y, cat->image[k % 2 + 2], TRANSPARENT_PUT);
   }
   if(cat->pos_x > LENGTH - 200){
      cat->speed *= -1;
   }
   if(cat->pos_x < 0 && cat->speed < 0){
      cat->speed *= -1;
   }
   cat->pos_x += cat->speed;
}

void draw_mushroom(Mushroom *mushroom){
   if(mushroom->type == 1){
      setcolor(WHITE);
      setfillstyle(SOLID_FILL, WHITE);
      bar(mushroom->pos_x - 2, mushroom->pos_y, mushroom->pos_x + 2, mushroom->pos_y + 20);
      setcolor(BLACK);
      setfillstyle(SOLID_FILL, COLOR(205, 133, 63));
      fillellipse(mushroom->pos_x, mushroom->pos_y, mushroom->size * 1.5, mushroom->size * 0.8);
   }
   if(mushroom->type == 2){
      setcolor(WHITE);
      setfillstyle(SOLID_FILL, WHITE);
      bar(mushroom->pos_x - 2, mushroom->pos_y, mushroom->pos_x + 2, mushroom->pos_y + 20);
      setcolor(BLACK);
      setfillstyle(SOLID_FILL, RED);
      fillellipse(mushroom->pos_x, mushroom->pos_y, mushroom->size * 1.5, mushroom->size * 0.8);
      setcolor(WHITE);
      setfillstyle(SOLID_FILL, WHITE);
      fillellipse(mushroom->pos_x, mushroom->pos_y, 2, 2);
      fillellipse(mushroom->pos_x - 1, mushroom->pos_y - 1, 2, 2);
      fillellipse(mushroom->pos_x - 11, mushroom->pos_y + 2, 2, 2);
      fillellipse(mushroom->pos_x + 2, mushroom->pos_y - 5, 2, 2);
   }
}



